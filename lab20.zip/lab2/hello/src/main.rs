#![no_main]
#![no_std]

use core::fmt::Write;
use cortex_m_rt::entry;
use embedded_hal::delay::DelayNs;
use microbit::{
    hal::{
        delay::Delay,
        twim,
        uarte::{Baudrate, Parity, Uarte},
    },
    pac::twim0::frequency::FREQUENCY_A,
    Board,
};
use lsm303agr::{Lsm303agr, MagMode, MagOutputDataRate};

#[panic_handler]
fn panic_handler(_info: &core::panic::PanicInfo) -> ! {
    loop {}
}

#[entry]
fn main() -> ! {
    let board = Board::take().unwrap();
    
    let mut serial = Uarte::new(
        board.UARTE0,
        board.uart.into(),
        Parity::EXCLUDED,
        Baudrate::BAUD115200,
    );
    writeln!(serial, "Starting compass readings...\r").unwrap();
    
    let i2c = twim::Twim::new(
        board.TWIM0,
        board.i2c_internal.into(),
        FREQUENCY_A::K100,
    );
    
    let mut sensor = Lsm303agr::new_with_i2c(i2c);
    sensor.init().unwrap();
    
    let mut delay = Delay::new(board.SYST);
    sensor.set_mag_mode_and_odr(&mut delay, MagMode::HighResolution, MagOutputDataRate::Hz10).unwrap();
    
    loop {
        // if sensor.mag_status().unwrap().x_new_data() {
            match sensor.magnetic_field() {
                Ok(data) => {
                    writeln!(
                        serial, 
                        "X: {:.2}, Y: {:.2}, Z: {:.2}\r", 
                        data.x_raw(), 
                        data.y_raw(), 
                        data.z_raw()
                    ).unwrap();
                },
                Err(e) => {
                    // writeln!(serial, "").unwrap();
                }
            }
        // }
        delay.delay_ms(50);
    }
}