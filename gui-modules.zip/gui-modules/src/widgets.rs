// Реэкспортируем все публичные типы
pub use self::{button::Button, label::Label, window::Window};

// Подключаем подмодули
mod button;
mod label;
mod window;

pub trait Widget {
    /// Ширина self.
    fn width(&self) -> usize;

    /// Прорисовка виджета в буфер.
    fn draw_into(&self, buffer: &mut dyn std::fmt::Write) -> std::fmt::Result;

    /// Прорисовка виджета.
    fn draw(&self) {
        let mut buffer = String::new();
        let _ = self.draw_into(&mut buffer);
        println!("{buffer}");
    }
}
